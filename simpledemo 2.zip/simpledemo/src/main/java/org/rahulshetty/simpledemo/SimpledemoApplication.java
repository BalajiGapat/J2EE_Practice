package org.rahulshetty.simpledemo;

import org.rahulshetty.simpledemo.Model.Library;
import org.rahulshetty.simpledemo.Repositories.LibraryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpledemoApplication implements CommandLineRunner {

	@Autowired
	LibraryInterface librepo;
	public static void main(String[] args) {
		SpringApplication.run(SimpledemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Library libentity =librepo.findById("isbn01").get();
		System.out.println(libentity.getAisle());
	}
}
