package org.rahulshetty.simpledemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpledemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
